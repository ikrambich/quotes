<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
#app {
  margin-top : 60px;
}
</style>
